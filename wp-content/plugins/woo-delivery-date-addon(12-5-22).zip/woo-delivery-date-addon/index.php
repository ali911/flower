<?php // Silent is gold
