<?php
if ( !defined( 'ABSPATH' ) ) {exit;}

class McisoeCustomerData
{
    private $helpers;
    public $customer_data;
    private $options;
    private $order;

    public function __construct( $options, $order )
    {
        require_once MCISOE_PLUGIN_DIR . 'helpers/mcisoe_helpers.php';
        $this->helpers       = new McisoeHelpers;
        $this->customer_data = '';
        $this->options       = $options;
        $this->order         = $order;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get customer data
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public function get_customer_data()
    {
        $order_id = $this->order->get_id();
        if ( !$order_id ) {
            return;
        }
        //Get order number
        $order_number = $this->build_order_number( $order_id );

        //Select shipping or billing address
        $response_address = $this->select_address( $order_id );
        $address          = $response_address['address'];
        $address_error    = $response_address['address_error'];

        //Select phone shipping or billing
        $phone = $this->select_phone( $order_id );

        //Get customer email
        $customer_email = $this->get_customer_email();

        //Get customer notes
        $customer_notes = $this->get_customer_notes();

        //Get delivery date
        $delivery_date = $this->get_delivery_date( $order_id );

        //If hide customer
        if ( $this->options->hide_customer == '1' ) {
            $this->customer_data = '';
            return $this->customer_data;

        } else {

            //Print customer data from template. Select file in child theme
            require_once $this->helpers->search_in_child_theme( 'mcisoe_email_customer_data.php', $this->options->auth_premium );
            $email_customer_data = new MciSoeEmailCustomerData( $order_number, $address_error, $address, $phone, $customer_email, $delivery_date, $customer_notes, $this->options->auth_premium, $this->order );

            $this->customer_data = $email_customer_data->get();

            return $this->customer_data;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private function build_order_number( $order_id )
    {
        if ( $this->options->show_order_number == '1' ) {
            $label_order_number = __( 'Order number:', 'supplier-order-email' );
            $label_order_date = __( 'Shipping Date:', 'supplier-order-email' );
            $label_order_number .= ' ';
            $order_number = $order_id;
            $order_number = sanitize_text_field( $this->order->get_order_number() );
            $order_number = $label_order_number . $order_number;
            
           
            $get_delry_date =  get_post_meta( $order_id, 'ctm_date_picker', true );

            $shipping_date_ = explode("/", $get_delry_date);
            $from_unix_time = mktime(0, 0, 0, $shipping_date_[0], $shipping_date_[1], $shipping_date_[2]);
            $day_before = strtotime("yesterday", $from_unix_time);
            $tomorrow = date('m/d/Y', $day_before);

            $order_number = $label_order_date . $tomorrow;


        } else {
            $order_number = '';
        }
        return $order_number;
    }

    private function select_address( $order_id )
    {
        $shipping_address = $this->order->get_formatted_shipping_address();
        $billing_address  = $this->order->get_formatted_billing_address();
        $address_error    = false;
        if ( empty( $shipping_address ) && $this->options->replace_address == '1' ) {
            $address = $billing_address;
        } else {
            if ( !empty( $shipping_address ) ) {
                $address = $shipping_address;
            } else {
                $address_error = true;
                $address       = __( 'The shipping address are empty because the order has no address. Contact us to solve it.', 'supplier-order-email' );
            }
        }
        $response = array(
            'address'       => $address,
            'address_error' => $address_error,
        );
        return $response;
    }

    private function select_phone( $order_id )
    {
        if ( $this->options->show_customer_phone == '1' ) {
            $phone_shipping = $this->order->get_shipping_phone();
            $phone_billing  = $this->order->get_billing_phone();
            if ( !empty( $phone_shipping ) && !isset( $address_error ) ) {
                $phone = $phone_shipping;
            } else {
                if ( !empty( $phone_billing ) ) {
                    $phone = $phone_billing;
                } else {
                    $phone = '';
                }
            }
        } else {
            $phone = '';
        }
        return $phone;
    }

    private function get_customer_email()
    {
        if ( $this->options->show_customer_email == '1' ) {
            $customer_email = sanitize_email( $this->order->get_billing_email() );
        } else {
            $customer_email = '';
        }
        return $customer_email;
    }

    private function get_customer_notes()
    {
        if ( $this->options->show_notes == '1' ) {
            $customer_note_label = '<strong>' . __( 'Note:', 'supplier-order-email' ) . '</strong> ';
            $customer_notes      = $customer_note_label . sanitize_text_field( $this->order->get_customer_note() );
        } else {
            $customer_notes = '';
        }
        return $customer_notes;
    }

    private function get_delivery_date( $order_id )
    {
        if ( $this->options->auth_premium == '1' ) {
            $delivery_date = get_post_meta( $order_id, '_delivery_date', true );

            if ( !empty( $delivery_date ) ) {
                $delivery_date_label = '<strong>' . __( 'Delivery date:', 'supplier-order-email' ) . '</strong> ';
                $delivery_date       = $delivery_date_label . sanitize_text_field( $delivery_date );
            } else {
                $delivery_date = '';
            }
        } else {
            $delivery_date = '';
        }
        return $delivery_date;
    }

}